function irPagina(url) {
    window.location.href = url;
}