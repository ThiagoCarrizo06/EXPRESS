document.getElementById('btnAddDiv').addEventListener('click', () => {
    const content = document.getElementById('content');
    const newDiv = document.createElement('div');
    newDiv.innerHTML = '<p>Este es el nuevo div agregado dinámicamente.</p>';
    content.appendChild(newDiv);
  });
  
  document.getElementById('btnAddP').addEventListener('click', () => {
    const content = document.getElementById('content');
    const newP = document.createElement('p');
    newP.innerHTML = 'Este es un nuevo párrafo agregado dinámicamente.';
    content.appendChild(newP);
  });
  