document.getElementById('campoTexto').addEventListener('keypress', (e) => {
    console.log(`Tecla presionada: ${e.key}`);
});
