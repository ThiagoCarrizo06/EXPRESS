document.getElementById('botonClick').addEventListener('click', () => {
    alert('¡Hiciste click!');
});
