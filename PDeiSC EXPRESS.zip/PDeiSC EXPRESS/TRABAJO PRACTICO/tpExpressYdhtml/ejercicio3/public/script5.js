document.getElementById('botonDobleClick').addEventListener('dblclick', () => {
    alert('¡Doble click detectado!');
});
