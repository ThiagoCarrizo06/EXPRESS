document.addEventListener('DOMContentLoaded', () => {
    const boton = document.getElementById('botonContar');
    const contenedor = document.getElementById('miContenedor');
    const resultado = document.getElementById('resultado');

    boton.addEventListener('click', () => {
        const hijos = contenedor.children.length;
        resultado.textContent = `El contenedor tiene ${hijos} hijo(s).`;
    });
});
