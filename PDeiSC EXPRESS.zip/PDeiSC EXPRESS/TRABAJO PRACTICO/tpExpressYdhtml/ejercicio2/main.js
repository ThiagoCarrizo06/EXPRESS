const express = require('express');
const app = express();
const path = require('path');

// Servimos archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Rutas para cada componente
app.get('/comp1', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'comp1.html'));
});

app.get('/comp2', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'comp2.html'));
});

app.get('/comp3', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'comp3.html'));
});

app.get('/comp4', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'comp4.html'));
});

app.get('/comp5', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'comp5.html'));
});

// Arrancar servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
