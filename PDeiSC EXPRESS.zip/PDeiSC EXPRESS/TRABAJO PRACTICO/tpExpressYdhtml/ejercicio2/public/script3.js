const caja = document.getElementById('caja');

caja.addEventListener('mouseout', () => {
    caja.style.backgroundColor = 'lightcoral';
});
