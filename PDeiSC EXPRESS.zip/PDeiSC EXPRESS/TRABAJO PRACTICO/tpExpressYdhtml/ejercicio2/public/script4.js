document.getElementById('campo-texto').addEventListener('keypress', (e) => {
    console.log(`Tecla presionada: ${e.key}`);
});
