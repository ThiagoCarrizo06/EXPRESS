document.getElementById('boton-click').addEventListener('click', () => {
    alert('¡Hiciste click!');
});
