document.getElementById('caja').addEventListener('mouseover', () => {
    alert('¡Pasaste el mouse sobre la caja!');
});
