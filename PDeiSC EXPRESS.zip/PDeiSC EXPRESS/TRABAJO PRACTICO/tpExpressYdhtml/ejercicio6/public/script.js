document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registroForm");
  const mensajeExito = document.getElementById("mensajeExito");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    // Validaciones básicas
    const nombre = form.nombre.value.trim();
    const edad = parseInt(form.edad.value, 10);
    const email = form.email.value.trim();
    const genero = form.genero.value;
    const suscripcion = form.suscripcion.value;

    if (nombre === "" || isNaN(edad) || edad < 1 || email === "" || genero === "" || !suscripcion) {
      alert("Por favor, completá todos los campos obligatorios correctamente.");
      return;
    }

    // Mostrar mensaje de éxito
    mensajeExito.style.display = "block";

    // Opcional: ocultar mensaje luego de unos segundos
    setTimeout(() => {
      mensajeExito.style.display = "none";
    }, 4000);

    // Resetear formulario
    form.reset();
  });
});
